import {allDirections,searchTeachers,answerQuestion,getFaqAnswer,sourceFreshness,validateData} from '/src/engine.mjs';

const $=id=>document.getElementById(id);
let catalog,knowledge;
let interests=[];
let activePanel='resources';
let toastTimer;
const element=(tag,text='',className='')=>{const node=document.createElement(tag);if(text)node.textContent=text;if(className)node.className=className;return node;};
const list=(items,ordered=false)=>{const node=element(ordered?'ol':'ul');items.forEach(text=>node.append(element('li',text)));return node;};
function sourceLink(source){const a=element('a',`${source.title} ↗`);a.href=source.url;a.target='_blank';a.rel='noopener noreferrer';return a;}
function toast(message){clearTimeout(toastTimer);$('toast').textContent=message;toastTimer=setTimeout(()=>$('toast').textContent='',3500);}
async function copy(text){try{await navigator.clipboard.writeText(text);toast('已复制，可以放入你的学习记录。');}catch{toast('当前浏览器无法自动复制，请选中页面文字手动复制。');}}
function sourceBlock(sources){const box=element('div','','sources');box.append(element('strong','核验来源'));sources.forEach(source=>{box.append(sourceLink(source));box.append(element('small',`查阅：${source.checkedAt} · ${source.verification==='official-search-index'?'官方页面检索索引，建议打开原文复核':'已读取官方来源'}`,'evidence'));});return box;}
function switchPanel(name){activePanel=name;$('resources-panel').hidden=name!=='resources';$('questions-panel').hidden=name!=='questions';$('show-resources').setAttribute('aria-pressed',String(name==='resources'));$('show-questions').setAttribute('aria-pressed',String(name==='questions'));}

function renderInterests(){
  $('interests').replaceChildren();
  for(const tag of ['人工智能','知识图谱','计算机视觉','物联网','边缘计算','数据挖掘']){
    const button=element('button',tag);button.type='button';button.setAttribute('aria-pressed',String(interests.includes(tag)));
    button.addEventListener('click',()=>{interests=interests.includes(tag)?interests.filter(t=>t!==tag):[...interests,tag];button.setAttribute('aria-pressed',String(interests.includes(tag)));renderTeachers();});
    $('interests').append(button);
  }
}
function renderTeachers(){
  const rows=searchTeachers(catalog.teachers,{query:$('search').value,direction:$('direction').value,college:$('college').value,undergraduateOnly:$('undergraduate').checked,interests});
  $('result-count').textContent=`找到 ${rows.length} 位教师 / 已收录 ${catalog.teachers.length} 位`;
  const container=$('teacher-list');container.replaceChildren();
  if(!rows.length){const empty=element('div','','empty');empty.append(element('h3','暂时没有匹配的资料'),element('p','试试更宽泛的关键词，或清空筛选。未收录不代表深大没有相关老师。'));const reset=element('button','清空筛选','primary');reset.addEventListener('click',resetFilters);empty.append(reset);container.append(empty);return;}
  for(const {teacher:t,matchedTags} of rows){
    const card=element('article','','teacher-card');
    const top=element('div','','card-top');const avatar=element('span',t.name.slice(0,1),'avatar');avatar.setAttribute('aria-hidden','true');
    const title=element('div');title.append(element('h3',t.name),element('div',t.title??'职称待核验','title-note'));
    top.append(avatar,title);card.append(top,element('p',t.summary,'card-summary'));
    const tags=element('div','','tags');t.directions.forEach(tag=>tags.append(element('span',tag,`tag${matchedTags.includes(tag)?' matched':''}`)));card.append(tags);
    if(interests.length) card.append(element('p',matchedTags.length?`匹配理由：你选择了 ${matchedTags.join('、')}`:'本次兴趣未命中；仍可浏览公开方向。','match-note'));
    card.append(element('div',t.recruitment.status==='页面欢迎本科生'?'官网提到欢迎本科生 · 当前名额待确认':'本科生参与条件待进一步确认','recruitment'));
    const bottom=element('div','','card-bottom');bottom.append(element('small',`官网资料 · ${t.source.checkedAt}`));
    const details=element('button','查看资料 ↗','detail-button');details.setAttribute('aria-label',`查看${t.name}资料`);details.addEventListener('click',()=>showTeacher(t));bottom.append(details);card.append(bottom);container.append(card);
  }
}
function resetFilters(){HTMLFormElement.prototype.reset.call($('filters'));interests=[];renderInterests();renderTeachers();}
function showTeacher(t){
  const box=$('detail-content');box.replaceChildren();
  const name=element('h2',t.name);name.id='detail-name';box.append(element('p','SZU · 教师公开资料','eyebrow'),name,element('p',`${t.school} / ${t.college} / ${t.researchUnit}`,'muted'));
  const dl=element('dl','','detail-meta');
  for(const [label,value] of [['官网职称',t.title??'未收录'],['研究方向',t.directions.join('、')],['工作邮箱',t.publicEmail??'未收录'],['核验日期',t.source.checkedAt],['网页更新',t.source.pageUpdatedAt??'官网页面未明确显示'],['资料状态',sourceFreshness(t.source)]])dl.append(element('dt',label),element('dd',value));
  box.append(dl,element('p',t.summary),element('h3','本科生参与说明'),element('p',t.recruitment.note,'note'));
  box.append(element('h3','主页列示成果'));
  if(t.representativeWorks.length){box.append(list(t.representativeWorks.map(w=>`${w.title} · ${w.venue} ${w.year}。${w.note}`)));}else box.append(element('p','本次尚未整理具体成果条目，请到官方主页查看。','muted'));
  box.append(element('h3','你可以先做的三件事'),element('p',t.editorial.note,'muted'),list(t.editorial.nextSteps,true));
  box.append(element('h3','联系前进一步确认'),list(t.pendingConfirmation));
  box.append(sourceBlock([t.source]),element('p',`核验依据摘要：${t.source.evidenceSummary}`,'evidence'));
  const copyButton=element('button','复制联系前准备清单','primary');copyButton.addEventListener('click',()=>copy(`${t.name}｜${t.college}\n${t.editorial.nextSteps.join('\n')}\n待确认：${t.pendingConfirmation.join('；')}\n来源：${t.source.url}\n查阅：${t.source.checkedAt}`));box.append(copyButton);
  if(!$('teacher-detail').open)$('teacher-detail').showModal();
  $('teacher-detail').scrollTop=0;
}
function renderAnswer(result){
  const box=$('answer');box.hidden=false;box.replaceChildren();
  box.append(element('span',({supported:'有资料依据',limited:'部分信息可回答',unknown:'已有资料无法确认'})[result.status],'mode'));
  box.append(element('h2',result.heading),element('p',result.answer,'answer-body'),element('h3','下一步可以做'),list(result.actions,true));
  for(const id of result.teacherIds){const t=catalog.teachers.find(t=>t.id===id);if(t){const button=element('button',`查看${t.name}资料 ↗`,'quiet');button.addEventListener('click',()=>showTeacher(t));box.append(button);}}
  if(result.citations.length)box.append(sourceBlock(result.citations));
  box.append(element('p',result.limitation,'note'),element('p',result.provenance,'muted'));
  const button=element('button','复制下一步行动','quiet');button.addEventListener('click',()=>copy(`${result.heading}\n${result.actions.join('\n')}\n${result.citations.map(s=>`${s.title} ${s.url}`).join('\n')}`));box.append(button);
}
function renderFaqs(){
  const container=$('faq-list');container.replaceChildren();
  knowledge.faqs.forEach(f=>{const button=element('button','','faq-button');button.append(element('span',f.question),element('span','↗'));button.addEventListener('click',()=>{$('question').value=f.question;renderAnswer(getFaqAnswer(f.id,catalog,knowledge));$('answer').scrollIntoView({block:'start',behavior:'smooth'});});container.append(button);});
}
async function load(){
  $('loading').hidden=false;$('load-error').hidden=true;$('resources-panel').hidden=true;$('questions-panel').hidden=true;
  $('show-resources').disabled=true;$('show-questions').disabled=true;
  try{
    const values=await Promise.all(['/data/szu-teachers.json','/data/research-faq.json'].map(async url=>{const response=await fetch(url,{signal:AbortSignal.timeout(10000)});if(!response.ok)throw new Error('读取失败');return response.json();}));
    const errors=validateData(values[0],values[1]);if(errors.length)throw new Error('资料校验失败');
    [catalog,knowledge]=values;
    $('teacher-count').textContent=catalog.teachers.length;$('faq-count').textContent=knowledge.faqs.length;$('checked-date').textContent=catalog.checkedAt;
    $('direction').replaceChildren(new Option('全部方向',''),...allDirections(catalog.teachers).map(t=>new Option(t,t)));
    $('college').replaceChildren(new Option('全部已收录学院',''),...Array.from(new Set(catalog.teachers.map(t=>t.college))).map(t=>new Option(t,t)));
    renderInterests();renderTeachers();renderFaqs();switchPanel(activePanel);
    $('show-resources').disabled=false;$('show-questions').disabled=false;
  }catch{$('load-error').hidden=false;}finally{$('loading').hidden=true;}
}
$('show-resources').addEventListener('click',()=>switchPanel('resources'));
$('show-questions').addEventListener('click',()=>switchPanel('questions'));
$('filters').addEventListener('submit',event=>event.preventDefault());
$('search').addEventListener('input',renderTeachers);
for(const id of ['direction','college','undergraduate'])$(id).addEventListener('change',renderTeachers);
$('reset').addEventListener('click',resetFilters);
$('close-detail').addEventListener('click',()=>$('teacher-detail').close());
$('question-form').addEventListener('submit',event=>{event.preventDefault();renderAnswer(answerQuestion($('question').value,catalog,knowledge));});
$('retry').addEventListener('click',load);
await load();
