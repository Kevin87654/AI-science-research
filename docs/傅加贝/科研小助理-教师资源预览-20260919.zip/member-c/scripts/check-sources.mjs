// Explicit, read-only check. It does not update verification dates or overwrite reviewed data.
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const {teachers}=JSON.parse(await readFile(new URL('../data/szu-teachers.json',import.meta.url),'utf8'));
let failed=0;
for(const teacher of teachers){
  const url=new URL(teacher.source.url);
  if(url.protocol!=='https:' || url.hostname!=='aisc.szu.edu.cn')throw new Error('Unapproved source host');
  try {
    const response=await fetch(url,{signal:AbortSignal.timeout(15000),redirect:'error'});
    const html=await response.text();
    const foundName=html.includes(teacher.name);
    const foundEmail=html.includes(teacher.publicEmail);
    const passed=response.ok&&foundName&&foundEmail;
    if(!passed)failed++;
    console.log(JSON.stringify({id:teacher.id,url:url.href,httpStatus:response.status,foundName,foundEmail,passed,checkedAt:new Date().toISOString(),sha256:createHash('sha256').update(html).digest('hex')}));
  }catch(error){failed++;console.log(JSON.stringify({id:teacher.id,url:url.href,passed:false,error:error.name}));}
}
process.exitCode=failed?1:0;
