import {createServer} from 'node:http';
import {readFile,realpath} from 'node:fs/promises';
import {resolve,relative,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = await realpath(fileURLToPath(new URL('../',import.meta.url)));
const port = Number(process.env.PORT ?? 4173);
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8'};
export function isPublicPath(path) {
  return /^(preview\/(index\.html|app\.mjs|style\.css)|src\/engine\.mjs|data\/(szu-teachers|research-faq)\.json)$/.test(path);
}
export const server = createServer(async(req,res)=>{
  if(!['GET','HEAD'].includes(req.method)) {res.writeHead(405,{Allow:'GET, HEAD'});res.end();return;}
  try {
    const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    const path=pathname==='/' ? 'preview/index.html' : pathname.replace(/^\//,'');
    if(!isPublicPath(path)) {res.writeHead(404);res.end('Not found');return;}
    const file=await realpath(resolve(root,path));
    const rel=relative(root,file);
    if(rel.startsWith(`..${sep}`) || rel==='..') {res.writeHead(403);res.end();return;}
    const content=await readFile(file);
    res.writeHead(200,{'Content-Type':types[extname(file)]??'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'"});
    res.end(req.method==='HEAD'?undefined:content);
  } catch {res.writeHead(404);res.end('Not found');}
});
if(process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  server.listen(port,'127.0.0.1',()=>console.log(`教师资源预览：http://127.0.0.1:${port}`));
  server.on('error',error=>{console.error(`预览启动失败：${error.code}`);process.exitCode=1;});
}
