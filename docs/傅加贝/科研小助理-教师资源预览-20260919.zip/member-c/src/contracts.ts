/** Proposed C-module contracts v1.0.0; reconcile with the main repo before merging. */
export interface Source {
  id: string;
  title: string;
  url: string;
  publisher: string;
  checkedAt: string; // YYYY-MM-DD: the day the source was read
  pageUpdatedAt: string | null; // null means unknown, never use checkedAt instead
  verification: "official-page-read" | "official-search-index";
  evidenceSummary: string;
  supportedFields?: string[];
}
export interface Teacher {
  id: string;
  type: "mentor";
  name: string;
  school: string;
  college: string;
  researchUnit: string;
  title: string | null;
  directions: string[];
  summary: string;
  publicEmail: string | null;
  source: Source;
  recruitment: { status: string; note: string; currentAvailability: "unknown" };
  representativeWorks: Array<{title:string;year:number;venue:string;sourceId:string;verification:"listed-on-profile";note:string}>;
  editorial: {suggestedMajors:string[];note:string;nextSteps:string[]};
  pendingConfirmation: string[];
  isDemo: false;
}
export interface Catalog {schemaVersion:string;checkedAt:string;scope:string;notice:string;teachers:Teacher[]}
export interface Faq {id:string;question:string;triggers:string[];category:string;answer:string;actions:string[];sourceIds:string[];limit:string;checkedAt:string;editorial:boolean}
export interface Knowledge {schemaVersion:string;mode:"curated-rules";sources:Source[];faqs:Faq[]}
export interface Answer {
  mode: "curated" | "directory" | "fallback";
  status: "supported" | "limited" | "unknown"; // evidence coverage, NOT model confidence
  heading: string;
  answer: string;
  actions: string[];
  citations: Source[];
  teacherIds: string[];
  limitation: string;
  provenance: string;
}
export interface SearchOptions {query?:string;direction?:string;college?:string;undergraduateOnly?:boolean;interests?:string[]}
export interface Match {teacher:Teacher;matchedTags:string[];reasons:string[];disclaimer:string}
