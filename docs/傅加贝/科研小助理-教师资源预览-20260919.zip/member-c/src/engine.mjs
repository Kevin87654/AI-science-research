// Framework-free functions. Data is supplied by the caller, not fetched here.
export const ALIASES = Object.freeze({
  "ai": "人工智能", "人工智慧": "人工智能", "大模型": "AIGC",
  "agent": "智能体", "iot": "物联网", "智能物联网": "物联网",
  "cv": "计算机视觉", "nlp": "自然语言处理", "推荐服务": "推荐系统",
  "多模态机器学习": "多模态学习", "云边计算": "边缘计算"
});
const normalize = (value) => String(value ?? "").normalize("NFKC").trim().toLowerCase();
export const canonicalTag = (value) => ALIASES[normalize(value)] ?? String(value ?? "").trim();
export const unique = (values) => [...new Set(values)];

export function allDirections(teachers) {
  return unique(teachers.flatMap(t => t.directions)).sort((a,b) => a.localeCompare(b, "zh-CN"));
}

export function matchInterests(teacher, interests = []) {
  const requested = unique(interests.map(canonicalTag).filter(Boolean));
  const matchedTags = requested.filter(tag => teacher.directions.includes(tag));
  return { matchedTags, reasons: matchedTags.map(tag => `兴趣“${tag}”与官方介绍中的研究方向标签对应。`),
    disclaimer: "标签匹配是探索线索，不是导师评分或录取概率。" };
}

export function searchTeachers(teachers, options = {}) {
  const { query = "", direction = "", college = "", undergraduateOnly = false, interests = [] } = options;
  const terms = normalize(query).split(/\s+/u).filter(Boolean).map(canonicalTag).map(normalize);
  return teachers.filter(t => {
    const haystack = normalize([t.name,t.school,t.college,t.researchUnit,t.title,t.summary,...t.directions].join(" "));
    return terms.every(term => haystack.includes(term)) &&
      (!direction || t.directions.includes(canonicalTag(direction))) &&
      (!college || t.college === college) &&
      (!undergraduateOnly || t.recruitment.status === "页面欢迎本科生");
  }).map(teacher => ({ teacher, ...matchInterests(teacher, interests) }))
    .sort((a,b) => b.matchedTags.length - a.matchedTags.length || a.teacher.id.localeCompare(b.teacher.id));
}

export function sourceFreshness(source, today = new Date().toISOString().slice(0,10)) {
  const elapsed = Date.parse(today) - Date.parse(source.checkedAt);
  if (!Number.isFinite(elapsed) || elapsed < 0) return "核验日期异常";
  return elapsed > 90 * 86400000 ? "超过90天，建议重新核验" : "已核验页面，当前名额仍需确认";
}

export function sourceRegistry(catalog, knowledge) {
  return new Map([...catalog.teachers.map(t => t.source), ...knowledge.sources].map(s => [s.id,s]));
}

export function getFaqAnswer(id, catalog, knowledge) {
  const faq = knowledge.faqs.find(f => f.id === id);
  if (!faq) return unknownAnswer("没有找到这个常见问题。");
  const registry = sourceRegistry(catalog, knowledge);
  const citations = faq.sourceIds.map(id => registry.get(id));
  if (citations.some(s => !s)) return unknownAnswer("这条回答的来源不完整，请先核验资料。");
  return { mode: "curated", status: "supported", heading: faq.question, answer: faq.answer,
    actions: faq.actions, citations, teacherIds: [], limitation: faq.limit,
    provenance: "已整理的常见问题回答；行动建议由产品编辑编写，非实时 AI 生成。" };
}

function unknownAnswer(message = "已有资料无法确认这个问题。当前支持教师方向查询、公开邮箱和科研入门常见问题。") {
  return { mode: "fallback", status: "unknown", heading: "需要进一步确认", answer: message,
    actions: ["尝试输入具体教师姓名或研究方向，或选择下方常见问题。","涉及招募名额与截止日期时，请查看最新官方通知或向老师本人确认。"],
    citations: [], teacherIds: [], limitation: "未覆盖信息不等于不存在；系统没有进行实时全网检索。", provenance: "范围提示，无事实推断。" };
}

function hasTerm(text, term) {
  const word = normalize(term);
  if (/^[a-z]+$/.test(word)) return new RegExp(`(^|[^a-z])${word}($|[^a-z])`, "u").test(text);
  return text.includes(word);
}

export function answerQuestion(question, catalog, knowledge) {
  if (typeof question !== "string" || !question.trim()) return unknownAnswer("请先输入一个问题。");
  if (question.length > 500) return unknownAnswer("问题过长，请缩短到500字以内，聚焦一个问题。");
  const q = normalize(question);
  if (/人品|避雷|黑料|是不是人类|压榨|人渣|最好.*导师|导师.*最好/.test(q)) {
    return unknownAnswer("公开资料不能支持对导师人品的判断。你可以比较研究方向，并当面确认指导频率、任务安排和参与要求。");
  }
  if (/代写|伪造|编造|虚构|忽略.*规则|ignore.*instruction|system prompt|系统提示词/.test(q)) {
    return unknownAnswer("当前模块只查询已核验资料和科研入门内容，不提供虚构成果、论文代写或无来源的事实。");
  }
  const named = catalog.teachers.filter(t => q.includes(normalize(t.name)));
  if (/名额|截止|保证|保录|一定能|招生人数|今年.*招|现在.*招|目前.*招|最新论文|最新成果/.test(q)) {
    const result = unknownAnswer("已有教师介绍不能确认当前名额、截止时间、最新成果或录取结果，请以最新官方通知和老师本人回复为准。");
    return { ...result, citations: named.map(t => t.source), teacherIds: named.map(t => t.id) };
  }
  // Resolve named requests before generic FAQs: do not answer a different person's question.
  if (named.length) {
    const exactName = named.length === 1 && q === normalize(named[0].name);
    if (!exactName && !/研究|方向|介绍|资料|邮箱|联系|本科生|招募|招收|招不招/.test(q)) return unknownAnswer();
    const contact = /邮箱|联系/.test(q);
    const recruitment = /本科生|招募|招收|招不招/.test(q);
    const text = named.map(t => `${t.name}（${t.college}）：${contact ? `官网列示工作邮箱为 ${t.publicEmail}。` : recruitment ? t.recruitment.note : `公开方向包括${t.directions.join("、")}。`}`).join("\n");
    return { mode:"directory",status: recruitment ? "limited":"supported",heading:contact?"公开联系信息":recruitment?"官网中的参与说明":"教师公开方向",
      answer:text,actions:["打开对应官方介绍核对当前信息。","准备一个具体研究问题及真实经历，再自行联系。"],
      citations:named.map(t=>t.source),teacherIds:named.map(t=>t.id),limitation:"同名教师需结合学院区分；这里只查询首批计算机学院样本，职称和邮箱可能更新。",provenance:"依据已核验教师资料直接整理，非实时 AI 生成。" };
  }
  const exactFaq = knowledge.faqs.find(f => normalize(f.question) === q);
  if (exactFaq) return getFaqAnswer(exactFaq.id,catalog,knowledge);
  const tags = unique([...allDirections(catalog.teachers).filter(t => hasTerm(q,t)),
    ...Object.entries(ALIASES).filter(([key]) => hasTerm(q,key)).map(([,value])=>value)]);
  if (tags.length && (/老师|教师|导师|实验室|研究组|有哪些|找谁/.test(q) || tags.some(t=>normalize(t)===q) || Object.keys(ALIASES).includes(q))) {
    const found = searchTeachers(catalog.teachers,{interests:tags}).filter(t=>t.matchedTags.length).slice(0,5);
    if (!found.length) return unknownAnswer();
    return {mode:"directory",status:"limited",heading:"可进一步了解的教师",
      answer:found.map(({teacher,matchedTags})=>`${teacher.name}：匹配到${matchedTags.join("、")}。`).join("\n"),
      actions:["打开一位教师详情，核对方向及资料日期。","读一篇相关成果的摘要，写下想继续了解的问题。"],
      citations:found.map(t=>t.teacher.source),teacherIds:found.map(t=>t.teacher.id),
      limitation:"只按已收录的方向标签匹配，最多展示5项，不代表全校名单、优劣排序或招募承诺。",provenance:"公开研究方向 + 可解释标签规则。"};
  }
  const candidates = knowledge.faqs.map(f=>({f, hits:f.triggers.filter(t=>hasTerm(q,t))}))
    .filter(x=>x.hits.length).sort((a,b)=>Math.max(...b.hits.map(t=>t.length))-Math.max(...a.hits.map(t=>t.length)));
  if (candidates.length) {
    const result = getFaqAnswer(candidates[0].f.id,catalog,knowledge);
    return {...result,status:"limited",limitation:`匹配到相关常见问题，可能未覆盖提问中的所有细节。${result.limitation}`};
  }
  return unknownAnswer();
}

export function validateData(catalog, knowledge) {
  const errors = [];
  if (!Array.isArray(catalog?.teachers) || !Array.isArray(knowledge?.faqs) || !Array.isArray(knowledge?.sources)) return ["缺少 teachers / faqs / sources 数组"];
  const ids = new Set();
  const sourceIds = new Set();
  const checkSource = s => {
    if (!s || typeof s.id !== "string" || !s.id) { errors.push("缺少来源标识"); return; }
    if(sourceIds.has(s.id)) errors.push(`来源ID重复：${s.id}`);
    sourceIds.add(s.id);
    try { const u = new URL(s.url); if(u.protocol !== "https:" || u.username || u.password) throw Error(); } catch { errors.push(`来源URL无效：${s.id}`); }
    if(!/^\d{4}-\d{2}-\d{2}$/.test(s.checkedAt) || !Number.isFinite(Date.parse(s.checkedAt))) errors.push(`核验日期无效：${s.id}`);
    if(!s.title || !s.evidenceSummary || !s.publisher) errors.push(`来源证据不完整：${s.id}`);
  };
  for (const t of catalog.teachers) {
    if(ids.has(t.id)) errors.push(`教师ID重复：${t.id}`);
    ids.add(t.id);
    if(!t.id || !t.name || !t.college || !t.directions?.length || !t.summary) errors.push(`教师字段不完整：${t.id}`);
    checkSource(t.source);
    try { if (!new URL(t.source.url).hostname.endsWith(".szu.edu.cn")) errors.push(`非深大教师来源：${t.id}`); } catch { /* reported above */ }
    if(t.isDemo !== false) errors.push(`真实资料不能标记为演示用户数据：${t.id}`);
    if(t.recruitment?.currentAvailability !== "unknown") errors.push(`未经确认的实时名额：${t.id}`);
    if(t.publicEmail && !/^[^\s@]+@szu\.edu\.cn$/.test(t.publicEmail)) errors.push(`邮箱格式错误：${t.id}`);
    for(const work of t.representativeWorks ?? []) if(work.sourceId !== t.source.id) errors.push(`成果缺少来源：${t.id}`);
  }
  knowledge.sources.forEach(checkSource);
  const faqIds = new Set();
  for(const f of knowledge.faqs) {
    if(faqIds.has(f.id)) errors.push(`问答ID重复：${f.id}`);
    faqIds.add(f.id);
    if(!f.answer || !f.actions?.length || !f.sourceIds?.length || !f.triggers?.length) errors.push(`问答字段不完整：${f.id}`);
    for(const id of f.sourceIds ?? []) if(!sourceIds.has(id)) errors.push(`问答引用不存在：${f.id}/${id}`);
  }
  return errors;
}
