import type {Catalog,Knowledge,Answer} from './contracts';
export interface AnswerProvider {
  readonly kind:string;
  answer(question:string):Promise<Answer>;
}
export function createCuratedProvider(catalog:Catalog,knowledge:Knowledge):AnswerProvider;
