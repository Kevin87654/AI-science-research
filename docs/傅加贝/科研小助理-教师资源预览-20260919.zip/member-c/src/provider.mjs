import {answerQuestion,validateData} from './engine.mjs';

/** Async port for later service integration. This implementation never calls a model. */
export function createCuratedProvider(catalog,knowledge) {
  const errors=validateData(catalog,knowledge);
  if(errors.length)throw new Error(`Invalid trusted dataset: ${errors.join('; ')}`);
  const snapshot=structuredClone({catalog,knowledge});
  return Object.freeze({
    kind:'curated-rules',
    async answer(question){return answerQuestion(question,snapshot.catalog,snapshot.knowledge);}
  });
}
