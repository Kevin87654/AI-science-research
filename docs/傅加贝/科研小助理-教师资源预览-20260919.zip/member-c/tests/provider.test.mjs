import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createCuratedProvider} from '../src/provider.mjs';
const catalog=JSON.parse(await readFile(new URL('../data/szu-teachers.json',import.meta.url),'utf8'));
const knowledge=JSON.parse(await readFile(new URL('../data/research-faq.json',import.meta.url),'utf8'));
test('异步问答端口无需网络且不受调用方修改数据影响',async()=>{
  const copy=structuredClone(catalog);const provider=createCuratedProvider(copy,knowledge);
  copy.teachers.length=0;
  assert.equal(provider.kind,'curated-rules');
  assert.match((await provider.answer('姚俊梅的邮箱')).answer,/yaojunmei@szu.edu.cn/);
});
test('不完整可信库无法创建正式问答实例',()=>{
  const copy=structuredClone(knowledge);copy.faqs[0].sourceIds=['missing'];
  assert.throws(()=>createCuratedProvider(catalog,copy),/Invalid trusted dataset/);
});
