import test from 'node:test';
import assert from 'node:assert/strict';
import {server,isPublicPath} from '../scripts/serve.mjs';
test('预览服务器只暴露指定静态文件',async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base=`http://127.0.0.1:${server.address().port}`;
  try {
    assert.equal((await fetch(base+'/')).status,200);
    assert.match((await fetch(base+'/src/engine.mjs')).headers.get('content-type'),/javascript/);
    assert.equal((await fetch(base+'/data/szu-teachers.json')).status,200);
    for(const path of ['/README.md','/.env','/package.json','/%2e%2e%2fAI实施任务书.md'])assert.equal((await fetch(base+path)).status,404);
    assert.equal((await fetch(base+'/',{method:'POST'})).status,405);
    assert.equal(isPublicPath('preview/../../secret'),false);
  } finally {server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
});
