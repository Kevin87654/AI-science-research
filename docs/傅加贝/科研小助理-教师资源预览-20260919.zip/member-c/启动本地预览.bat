@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo 未检测到 Node.js。
  echo 请先安装 Node.js 24，然后重新双击此文件。
  echo 下载地址：https://nodejs.org/
  pause
  exit /b 1
)

echo 正在启动科研小助理教师资源预览……
echo 启动成功后，请在浏览器打开：http://127.0.0.1:4173/
echo 保持此窗口开启；需要停止时按 Ctrl+C。
echo.
node scripts\serve.mjs

echo.
echo 预览服务已停止。
pause
